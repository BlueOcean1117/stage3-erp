import React, { useMemo, useState } from "react";
import { jsPDF } from "jspdf";
import autoTable from "jspdf-autotable";
import { toast } from "react-toastify";
import API from "../../services/api";
import "../../styles/invoice.css";

function createInvoiceNoPreview() {
  const year = new Date().getFullYear();
  const stamp = String(Date.now()).slice(-6);
  return `INV-${year}-${stamp}`;
}

function formatDateInput(value) {
  const date = value ? new Date(value) : new Date();
  if (Number.isNaN(date.getTime())) return new Date().toISOString().slice(0, 10);
  return date.toISOString().slice(0, 10);
}

function formatDisplayDate(value) {
  if (!value) return "—";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "—";
  return date.toLocaleDateString("en-GB");
}

function money(value) {
  const number = Number(value) || 0;
  return new Intl.NumberFormat("en-US", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(number);
}

function integerToWords(value) {
  const number = Math.floor(Math.abs(Number(value) || 0));
  if (number === 0) return "Zero";

  const ones = [
    "Zero", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine",
    "Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen",
  ];
  const tens = ["", "", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety"];

  const chunkToWords = (chunk) => {
    let result = "";
    const hundred = Math.floor(chunk / 100);
    const rest = chunk % 100;

    if (hundred) {
      result += `${ones[hundred]} Hundred`;
      if (rest) result += " ";
    }

    if (rest < 20) {
      result += ones[rest];
    } else {
      const ten = Math.floor(rest / 10);
      const one = rest % 10;
      result += tens[ten];
      if (one) result += ` ${ones[one]}`;
    }

    return result.trim();
  };

  const parts = [];
  const scales = [
    { value: 10000000, label: "Crore" },
    { value: 100000, label: "Lakh" },
    { value: 1000, label: "Thousand" },
    { value: 1, label: "" },
  ];

  let remaining = number;
  for (const scale of scales) {
    if (remaining >= scale.value) {
      const chunk = Math.floor(remaining / scale.value);
      remaining %= scale.value;
      const words = chunkToWords(chunk);
      parts.push(scale.label ? `${words} ${scale.label}` : words);
    }
  }

  return parts.join(" ").replace(/\s+/g, " ").trim();
}

function amountToWords(amount) {
  const numeric = Number(amount) || 0;
  const rounded = Math.round(numeric * 100) / 100;
  const rupees = Math.floor(rounded);
  const paise = Math.round((rounded - rupees) * 100);

  const rupeeWords = integerToWords(rupees);
  if (!paise) return `${rupeeWords} Dollars Only`;
  return `${rupeeWords} Dollars and ${integerToWords(paise)} Cents Only`;
}

const createBlankRow = () => ({
  id: `${Date.now()}-${Math.random().toString(16).slice(2)}`,
  description: "",
  refPartInvNo: "",
  hsnCode: "",
  qty: "",
  unitPrice: "",
  amount: "",
});

const buildRowFromShipment = (item) => {
  const qty = Number(item.qty) || 0;
  const unitPrice = Number(item.unitPrice) || 0;
  return {
    id: `${Date.now()}-${Math.random().toString(16).slice(2)}`,
    description: item.description || "",
    refPartInvNo: item.refPartInvNo || "",
    hsnCode: item.hsnCode || "",
    qty: item.qty ?? "",
    unitPrice: item.unitPrice ?? "",
    amount: item.amount ?? qty * unitPrice,
  };
};

const STATIC_DECLARATION =
  "We declare that this invoice shows the actual price of the goods described and that all particulars are true and correct.";

const STATIC_COMPANY_ADDRESS = [
  "Blue Ocean Consulting",
  "Office No. 204, Crystal Tower, Business Bay, Pune - 411001, India",
  "GSTIN: 27AAACB0000A1Z5",
  "Email: accounts@blueoceanconsulting.com",
].join("\n");

const STATIC_BANK_DETAILS = [
  "Bank: HDFC Bank",
  "Account Name: Blue Ocean Consulting",
  "Account No: 012345678901",
  "IFSC: HDFC0000123",
  "Branch: Baner, Pune",
].join("\n");

const MIN_PDF_TABLE_ROWS = 14;
const PDF_GRID_LINE = [54, 54, 54];

const rowHasUserData = (item) => [
  item.description,
  item.refPartInvNo,
  item.hsnCode,
  item.qty,
  item.unitPrice,
].some((value) => String(value ?? "").trim() !== "");

export default function InvoicePage() {
  const [invoiceNo, setInvoiceNo] = useState(createInvoiceNoPreview());
  const [invoiceIssueDate, setInvoiceIssueDate] = useState(formatDateInput());
  const [blNo, setBlNo] = useState("");
  const [billTo, setBillTo] = useState({
    companyName: "",
    address: "",
    contactNumber: "",
  });
  const [items, setItems] = useState([createBlankRow()]);
  const [savedInvoiceId, setSavedInvoiceId] = useState("");
  const [recipientEmail, setRecipientEmail] = useState("");
  const [loadingBl, setLoadingBl] = useState(false);
  const [savingInvoice, setSavingInvoice] = useState(false);
  const [sendingInvoice, setSendingInvoice] = useState(false);

  const totalAmount = useMemo(
    () => items.reduce((sum, item) => sum + (Number(item.amount) || 0), 0),
    [items]
  );

  const totalInWords = useMemo(() => amountToWords(totalAmount), [totalAmount]);

  const updateBillTo = (field, value) => {
    setBillTo((prev) => ({ ...prev, [field]: value }));
  };

  const updateItem = (index, field, value) => {
    setItems((prev) =>
      prev.map((row, rowIndex) => {
        if (rowIndex !== index) return row;
        const next = { ...row, [field]: value };
        const qty = Number(next.qty) || 0;
        const unitPrice = Number(next.unitPrice) || 0;
        next.amount = qty * unitPrice;
        return next;
      })
    );
  };

  const addRow = () => setItems((prev) => [...prev, createBlankRow()]);

  const removeRow = (index) => {
    setItems((prev) => (prev.length > 1 ? prev.filter((_, i) => i !== index) : prev));
  };

  const lookupShipment = async () => {
    const searchBlNo = blNo.trim();
    if (!searchBlNo) {
      toast.warn("Enter BL No first");
      return;
    }

    setLoadingBl(true);
    try {
      const res = await API.get(`/shipment/by-bl/${encodeURIComponent(searchBlNo)}`);
      const data = res.data || {};

      setBillTo((prev) => ({
        ...prev,
        companyName: data.billTo?.companyName || prev.companyName,
        address: data.billTo?.address || prev.address,
        contactNumber: data.billTo?.contactNumber || prev.contactNumber,
      }));
      setBlNo(data.billTo?.blNo || searchBlNo);

      setRecipientEmail(data.billTo?.recipientEmail || "");

      if (data.invoiceDate) setInvoiceIssueDate(formatDateInput(data.invoiceDate));

      const mappedItems = Array.isArray(data.items) && data.items.length
        ? data.items.map(buildRowFromShipment)
        : [createBlankRow()];
      setItems(mappedItems);
      setSavedInvoiceId("");

      toast.success("Shipment details loaded from BL No");
    } catch (err) {
      const message = err.response?.data?.message || "Shipment not found for this BL No";
      toast.error(message);
    } finally {
      setLoadingBl(false);
    }
  };

  const buildPayload = () => ({
    invoiceNo: "auto",
    invoiceDate: invoiceIssueDate,
    billTo: {
      companyName: billTo.companyName,
      address: billTo.address,
      contactNumber: billTo.contactNumber,
      blNo,
    },
    items: items.map((item) => ({
      description: item.description,
      refPartInvNo: item.refPartInvNo,
      hsnCode: item.hsnCode,
      qty: Number(item.qty) || 0,
      unitPrice: Number(item.unitPrice) || 0,
      amount: Number(item.amount) || 0,
    })),
    totalAmount,
  });

  const saveInvoice = async ({ notify = true } = {}) => {
    setSavingInvoice(true);
    try {
      const payload = buildPayload();
      const res = await API.post("/invoice/create", payload);
      setSavedInvoiceId(res.data?._id || "");
      if (res.data?.invoiceNo) setInvoiceNo(res.data.invoiceNo);
      if (notify) {
        const generatedNo = res.data?.invoiceNo || invoiceNo;
        toast.success(`Invoice ${generatedNo} generated successfully`);
      }
      return res.data;
    } catch (err) {
      const message = err.response?.data?.message || "Failed to generate invoice";
      toast.error(message);
      return null;
    } finally {
      setSavingInvoice(false);
    }
  };

  const createPdfDocument = (payloadOverride) => {
    const doc = new jsPDF("p", "mm", "a4");
    const payload = payloadOverride || buildPayload();
    doc.setFont("times", "normal");

    const itemRows = items.map((item, index) => {
      const hasData = rowHasUserData(item);
      if (!hasData) {
        return [index + 1, "", "", "", "", "", ""];
      }

      const qtyText = String(item.qty ?? "").trim();
      const unitPriceText = String(item.unitPrice ?? "").trim();
      const qty = qtyText ? Number(item.qty) : NaN;
      const unitPrice = unitPriceText ? Number(item.unitPrice) : NaN;
      const amount = Number.isFinite(Number(item.amount))
        ? Number(item.amount)
        : (Number.isFinite(qty) ? qty : 0) * (Number.isFinite(unitPrice) ? unitPrice : 0);

      return [
        index + 1,
        item.description || "",
        item.refPartInvNo || "",
        item.hsnCode || "",
        Number.isFinite(qty) ? qty : "",
        Number.isFinite(unitPrice) ? money(unitPrice) : "",
        Number.isFinite(amount) ? money(amount) : "",
      ];
    });

    while (itemRows.length < MIN_PDF_TABLE_ROWS) {
      itemRows.push([itemRows.length + 1, "", "", "", "", "", ""]);
    }

    const tableBody = [
      ["", { content: "Supply Chain Service Charges", colSpan: 6, styles: { halign: "left" } }],
      ["", { content: `Mode - Sea ; BL No - ${payload.billTo.blNo || ""}`, colSpan: 6, styles: { halign: "left" } }],
      ...itemRows,
    ];

    doc.setFillColor(15, 23, 42);
    doc.rect(0, 0, 210, 28, "F");
    doc.setTextColor(255, 255, 255);
    doc.setFont("times", "bold");
    doc.setFontSize(18);
    doc.text("INVOICE", 14, 14);
    doc.setFont("times", "normal");
    doc.setFontSize(10);
    doc.text("BLUE OCEAN CONSULTING", 14, 20);
    doc.text("Creating Value", 14, 25);

    doc.setFillColor(240, 245, 255);
    doc.roundedRect(138, 8, 58, 18, 3, 3, "F");
    doc.setTextColor(17, 24, 39);
    doc.setFontSize(9);
    doc.text(`Invoice No: ${payload.invoiceNo}`, 142, 14);
    doc.text(`Issue Date: ${formatDisplayDate(payload.invoiceDate)}`, 142, 20);

    doc.setDrawColor(226, 232, 240);
    doc.roundedRect(14, 34, 182, 34, 3, 3);
    doc.setFontSize(11);
    doc.setTextColor(15, 23, 42);
    doc.text("Bill To", 18, 41);
    doc.setFontSize(10);
    doc.text(payload.billTo.companyName || "", 18, 47);
    doc.text(payload.billTo.address || "", 18, 52, { maxWidth: 110 });
    doc.text(`Contact: ${payload.billTo.contactNumber || ""}`, 18, 61);
    doc.text(`BL No: ${payload.billTo.blNo || ""}`, 120, 47);

    autoTable(doc, {
      startY: 74,
      head: [["Sr. No", "Description", "Ref Part Inv No", "HSN Code", "Qty (Pcs)", "Unit Price (USD)", "Amount (USD)"]],
      body: tableBody,
      theme: "grid",
      styles: {
        fontSize: 8,
        font: "times",
        cellPadding: 1.8,
        minCellHeight: 6.8,
        lineColor: PDF_GRID_LINE,
        lineWidth: 0.35,
        textColor: [17, 24, 39],
      },
      headStyles: {
        fillColor: [255, 255, 255],
        lineColor: PDF_GRID_LINE,
        lineWidth: 0.35,
        textColor: [15, 23, 42],
        fontStyle: "bold",
        halign: "center",
      },
      bodyStyles: {
        lineColor: PDF_GRID_LINE,
        lineWidth: 0.35,
      },
      columnStyles: {
        0: { cellWidth: 12, halign: "center" },
        1: { cellWidth: 58, halign: "left" },
        2: { cellWidth: 30, halign: "center" },
        3: { cellWidth: 18, halign: "center" },
        4: { cellWidth: 16, halign: "right" },
        5: { cellWidth: 23, halign: "right" },
        6: { cellWidth: 23, halign: "right" },
      },
      didParseCell: (data) => {
        if (data.section === "body" && (data.row.index === 0 || data.row.index === 1)) {
          data.cell.styles.fillColor = [255, 255, 255];
          data.cell.styles.fontStyle = data.row.index === 0 ? "bold" : "normal";
          data.cell.styles.halign = "left";
        }
      },
      margin: { left: 14, right: 14 },
    });

    const afterTableY = doc.lastAutoTable.finalY + 8;
    doc.setFillColor(248, 250, 252);
    doc.roundedRect(120, afterTableY, 76, 20, 3, 3, "F");
    doc.setFontSize(10);
    doc.text(`Total Amount: USD ${money(payload.totalAmount)}`, 124, afterTableY + 8);
    doc.text(totalInWords, 14, afterTableY + 16, { maxWidth: 180 });

    const footerY = afterTableY + 28;
    doc.setFontSize(8);
    doc.text("Declaration:", 14, footerY);
    doc.text(STATIC_DECLARATION, 14, footerY + 4, { maxWidth: 182 });
    doc.text("Company Address:", 14, footerY + 18);
    doc.text(STATIC_COMPANY_ADDRESS, 14, footerY + 22, { maxWidth: 80 });
    doc.text("Bank Details:", 110, footerY + 18);
    doc.text(STATIC_BANK_DETAILS, 110, footerY + 22, { maxWidth: 85 });

    return { doc, payload };
  };

  const openInvoicePreviewPopup = (payloadOverride, existingWindow = null) => {
    const { doc, payload } = createPdfDocument(payloadOverride);
    const blobUrl = doc.output("bloburl");

    const popup = existingWindow || window.open(blobUrl, "_blank", "width=980,height=760");
    if (popup) {
      if (existingWindow) {
        popup.location.href = blobUrl;
      }
      if (typeof popup.focus === "function") popup.focus();
      return payload.invoiceNo || "";
    }

    toast.warn("Invoice generated, but popup was blocked by the browser.");
    return payload.invoiceNo || "";
  };

  const downloadPdf = () => {
    const { doc, payload } = createPdfDocument();
    doc.save(`${payload.invoiceNo || "invoice"}.pdf`);
  };

  const handleGenerateInvoice = async () => {
    const previewWindow = window.open("", "_blank", "width=980,height=760");
    const saved = await saveInvoice({ notify: false });
    if (!saved) {
      if (previewWindow && !previewWindow.closed) previewWindow.close();
      return;
    }

    const payload = buildPayload();
    payload.invoiceNo = saved.invoiceNo || payload.invoiceNo;
    const generatedNo = openInvoicePreviewPopup(payload, previewWindow);
    toast.success(`Invoice ${generatedNo || payload.invoiceNo} generated and opened in popup`);
  };

  const handleSendInvoice = async () => {
    setSendingInvoice(true);
    try {
      let invoiceId = savedInvoiceId;
      if (!invoiceId) {
        const saved = await saveInvoice();
        invoiceId = saved?._id || "";
      }

      if (!invoiceId) return;

      const email = recipientEmail || window.prompt("Enter recipient email to send the invoice");
      if (!email) {
        toast.warn("Recipient email is required to send the invoice");
        return;
      }

      await API.post(`/invoice/send/${invoiceId}`, { to: email });
      toast.success("Invoice sent successfully");
    } catch (err) {
      const message = err.response?.data?.message || "Failed to send invoice";
      toast.error(message);
    } finally {
      setSendingInvoice(false);
    }
  };

  const handleReset = () => {
    setInvoiceNo(createInvoiceNoPreview());
    setInvoiceIssueDate(formatDateInput());
    setBillTo({
      companyName: "",
      address: "",
      contactNumber: "",
    });
    setBlNo("");
    setItems([createBlankRow()]);
    setSavedInvoiceId("");
    setRecipientEmail("");
  };

  return (
    <div className="invoice-page">
      <div className="invoice-shell">
        <div className="invoice-top">
          <div className="invoice-title-block">
            <div className="invoice-title">INVOICE</div>
            <div className="invoice-brand-row">
              <div className="invoice-brand-mark">BO</div>
              <div className="invoice-brand-copy">
                <div className="invoice-company">BLUE OCEAN CONSULTING</div>
                <div className="invoice-subtitle">“Creating Value”</div>
              </div>
            </div>
          </div>

          <div className="invoice-meta-card">
            <div className="meta-row">
              <span>Invoice No</span>
              <strong>{invoiceNo}</strong>
            </div>
            <div className="meta-row">
              <span>Invoice Issue Date</span>
              <strong>{formatDisplayDate(invoiceIssueDate)}</strong>
            </div>
          </div>
        </div>

        <div className="invoice-grid">
          <section className="invoice-card">
            <div className="card-heading">Bill To</div>
            <div className="field-grid two-up">
              <div className="invoice-field">
                <label>Company Name</label>
                <input
                  type="text"
                  value={billTo.companyName}
                  onChange={(e) => updateBillTo("companyName", e.target.value)}
                  placeholder="Company Name"
                />
              </div>
              <div className="invoice-field">
                <label>Contact Number</label>
                <input
                  type="text"
                  value={billTo.contactNumber}
                  onChange={(e) => updateBillTo("contactNumber", e.target.value)}
                  placeholder="Contact Number"
                />
              </div>
            </div>

            <div className="invoice-field">
              <label>Address</label>
              <textarea
                value={billTo.address}
                onChange={(e) => updateBillTo("address", e.target.value)}
                placeholder="Address"
                rows={3}
              />
            </div>
          </section>
        </div>

        <section className="invoice-card invoice-bl-card">
          <div className="card-heading">BL No</div>
          <div className="bill-search-row">
            <div className="invoice-field grow">
              <label>BL No (Search / Manual)</label>
              <input
                type="text"
                value={blNo}
                onChange={(e) => setBlNo(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && lookupShipment()}
                placeholder="Enter BL number"
              />
            </div>
            <button className="invoice-btn secondary" onClick={lookupShipment} disabled={loadingBl}>
              {loadingBl ? "Searching..." : "Search"}
            </button>
          </div>
          <div className="section-note">You can search by BL No or type manually and continue.</div>
        </section>

        <section className="invoice-card invoice-table-card">
          <div className="section-topbar">
            <div>
              <div className="card-heading">Bill Summary</div>
              <div className="section-note">Auto-populates from the selected BL No and can be edited manually.</div>
            </div>
            <button className="invoice-btn add" onClick={addRow}>+ Add Row</button>
          </div>

          <div className="table-wrap invoice-table-wrap">
            <table className="invoice-table">
              <thead>
                <tr>
                  <th>Sr No</th>
                  <th>Description</th>
                  <th>Ref Part Inv No</th>
                  <th>HSN Code</th>
                  <th>Qty (Pcs)</th>
                  <th>Unit Price (USD)</th>
                  <th>Amount (USD)</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                {items.map((item, index) => (
                  <tr key={item.id}>
                    <td>{index + 1}</td>
                    <td>
                      <input
                        type="text"
                        value={item.description}
                        onChange={(e) => updateItem(index, "description", e.target.value)}
                        placeholder="Description"
                      />
                    </td>
                    <td>
                      <input
                        type="text"
                        value={item.refPartInvNo}
                        onChange={(e) => updateItem(index, "refPartInvNo", e.target.value)}
                        placeholder="Ref Part Inv No"
                      />
                    </td>
                    <td>
                      <input
                        type="text"
                        value={item.hsnCode}
                        onChange={(e) => updateItem(index, "hsnCode", e.target.value)}
                        placeholder="HSN"
                      />
                    </td>
                    <td>
                      <input
                        type="number"
                        min="0"
                        step="1"
                        value={item.qty}
                        onChange={(e) => updateItem(index, "qty", e.target.value)}
                      />
                    </td>
                    <td>
                      <input
                        type="number"
                        min="0"
                        step="0.01"
                        value={item.unitPrice}
                        onChange={(e) => updateItem(index, "unitPrice", e.target.value)}
                      />
                    </td>
                    <td>
                      <input type="text" value={money(item.amount)} readOnly />
                    </td>
                    <td>
                      <button
                        className="row-delete"
                        onClick={() => removeRow(index)}
                        disabled={items.length === 1}
                      >
                        Remove
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>

        <div className="invoice-total-row">
          <aside className="invoice-summary-card">
            <div className="card-heading">Total Amount</div>
            <div className="total-value">USD {money(totalAmount)}</div>
            <div className="total-words">{totalInWords}</div>
            <div className="mini-box">
              <div>
                <span>Invoice No</span>
                <strong>{invoiceNo}</strong>
              </div>
              <div>
                <span>Issue Date</span>
                <strong>{formatDisplayDate(invoiceIssueDate)}</strong>
              </div>
            </div>
          </aside>
        </div>

        <div className="invoice-lower-grid">
          <section className="invoice-card">
            <div className="card-heading">Declaration</div>
            <p className="static-copy">{STATIC_DECLARATION}</p>
          </section>

          <section className="invoice-card">
            <div className="card-heading">Company Address</div>
            <pre className="static-pre">{STATIC_COMPANY_ADDRESS}</pre>
          </section>

          <section className="invoice-card">
            <div className="card-heading">Bank Details</div>
            <pre className="static-pre">{STATIC_BANK_DETAILS}</pre>
          </section>
        </div>

        <div className="invoice-actions">
          <button className="invoice-btn primary" onClick={handleGenerateInvoice} disabled={savingInvoice}>
            {savingInvoice ? "Generating..." : "Generate Invoice"}
          </button>
          <button className="invoice-btn dark" onClick={downloadPdf}>Download PDF</button>
          <button className="invoice-btn secondary" onClick={handleSendInvoice} disabled={sendingInvoice}>
            {sendingInvoice ? "Sending..." : "Send Invoice"}
          </button>
          <button className="invoice-btn light" onClick={handleReset}>Reset Form</button>
        </div>
      </div>
    </div>
  );
}